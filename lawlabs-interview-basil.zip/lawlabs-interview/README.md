# Interview Exercises

- Make sure you have .NET 8 installed
	- https://dotnet.microsoft.com/en-us/download/dotnet/8.0
- Build the project
- Run the exercises in order, trying to make the tests pass
- Ask questions if you are unsure about something
